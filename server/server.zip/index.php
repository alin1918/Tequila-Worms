<html>
<head>
<script type="text/javascript" src="http://10.10.1.154:8090/socket.io/socket.io.js"></script>
<script type="text/javascript" src="http://10.10.1.154:8090/socket.io/socket.net.js"></script>
<script type="text/javascript" src="http://ajax.aspnetcdn.com/ajax/jQuery/jquery-1.6.min.js"></script>

<script type="text/javascript">
    var net = require('net');
    var socket = new net.Socket({ fd: null,
  type: 'tcp4',
  allowHalfOpen: false
});
    socket.connect(8090,'10.10.1.154');
    socket.write('text');
    
//    socket.connect();
//
//    socket.on('connect', function(){
//        console.log('connected');
//        socket.send('hi!');
//    });
//
//    socket.on('message', function(data){
//        $("#box").html(data); //console.log('message recived: ' + data);
//    });
//
//
//    socket.on('disconnect', function(){
//        console.log('disconected');
//    });
//
//    $(function(){
//        $("#send2").click(function(){
//            socket.send($("#send").val());
//        })
//    })
</script>
</head>
<body>
    <div id="box"></div>
    <input type="text" id="send" />
    <input type="button" id="send2" />
</body>
</html>