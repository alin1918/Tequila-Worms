writer = {

    write : function (client) {
        
    },
    
    writeToAll : function () {
        console.log();
    }

}