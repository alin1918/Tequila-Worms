reader = {
    read : function (ev) {
        console.log(ev);
    }
    
}